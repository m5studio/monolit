from django.apps import AppConfig


class NewsConfig(AppConfig):
    name = 'apps.news'
    verbose_name = 'Новости'
    label = 'news'
