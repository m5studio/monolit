from django.apps import AppConfig


class MortgageConfig(AppConfig):
    name = 'apps.mortgage'
    verbose_name = 'Ипотека'
    label = 'mortgage'
