from django.views.generic import TemplateView

from django.db.models import Q

from apps.mortgage.models import Offer, WayToBuy
# from apps.realty.models.object import Object


class MortgageView(TemplateView):
    template_name = 'mortgage/mortgage.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_tite'] = 'Ипотека'
        context['mortgage_offers'] = Offer.objects.all().order_by('title')
        return context


class MortgageCorporactiveView(TemplateView):
    template_name = 'mortgage/corporactive.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_tite'] = 'Корпорактив'
        return context


class MortgageMilitaryView(TemplateView):
    template_name = 'mortgage/military.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_tite'] = 'Военная ипотека'

        # Check if object id=1 in WayToBuy exists and military is not None
        context['objects_military'] = None
        if WayToBuy.objects.filter(id=1).exists() and WayToBuy.objects.filter( ~Q(military=None) ):
            context['objects_military'] = WayToBuy.objects.get(id=1)

        return context


class MortgageMotherView(TemplateView):
    template_name = 'mortgage/mother.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_tite'] = 'Материнский капитал'
        return context
