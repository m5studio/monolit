from django.apps import AppConfig


class RealtyConfig(AppConfig):
    name = 'apps.realty'
    verbose_name = 'Недвижимость'
    label = 'realty'
