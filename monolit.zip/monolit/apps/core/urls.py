from django.urls import path

from apps.core.views import HomepageView


urlpatterns = [
    path('', HomepageView.as_view(), name='homepage'),
]
